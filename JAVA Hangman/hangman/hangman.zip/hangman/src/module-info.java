/**
 * 
 */
/**
 * 
 */
module hangman {
}